import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('/content/titanic.csv')
df.head()